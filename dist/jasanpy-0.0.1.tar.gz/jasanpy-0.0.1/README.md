# JasanPy

![Python Logo](https://www.python.org/static/community_logos/python-logo.png "jasanpy")

JasanPy is a package that allow you to easily access APIs provided by financial infrastructures. 
